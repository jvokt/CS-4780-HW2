CS 4780 HW2

Trevor Slaton (tms245)
Joseph Vokt (jpv52)

We used the following packages:

- sci-kit learn (exclusively for reading svm_light data directly to a sparse matrix)
- numpy
- scipy
- matplotlib

A few of these have other dependenices that you may need to install as well in order to run our code, depending on your machine and where you get the above packages.